TRUNCATE TABLE users;

-- Thêm dữ liệu mẫu

-- 1 Admin
INSERT INTO users (username, password, email, role, address, fullname, phone) VALUES
('admin1', '0', 'admin1@example.com', 'admin', '789 Boulevard, City', 'Admin One', '0111222333');

-- 4 Coach
INSERT INTO users (username, password, email, role, address, fullname, phone) VALUES
('coach1', '0', 'coach1@example.com', 'coach', '456 Avenue, City', 'Coach One', '0987654321'),
('coach2', 'password_hash_coach2', 'coach2@example.com', 'coach', '654 Avenue, City', 'Coach Two', '0778899000'),
('coach3', 'password_hash_coach3', 'coach3@example.com', 'coach', '222 Road, Town', 'Coach Three', '0887766554'),
('coach4', 'password_hash_coach4', 'coach4@example.com', 'coach', '333 Highway, Town', 'Coach Four', '0443322110');

-- 10 User
INSERT INTO users (username, password, email, role, address, fullname, phone) VALUES
('user1', '0', 'user1@example.com', 'user', '123 Street, City', 'User One', '0123456789'),
('user2', 'password_hash_user2', 'user2@example.com', 'user', '321 Street, City', 'User Two', '0223344556'),
('user3', 'password_hash_user3', 'user3@example.com', 'user', '111 Lane, Town', 'User Three', '0334455667'),
('user4', 'password_hash_user4', 'user4@example.com', 'user', '444 Road, Town', 'User Four', '0556677889'),
('user5', 'password_hash_user5', 'user5@example.com', 'user', '555 Lane, Village', 'User Five', '0667788990'),
('user6', 'password_hash_user6', 'user6@example.com', 'user', '666 Street, Village', 'User Six', '0778899001'),
('user7', 'password_hash_user7', 'user7@example.com', 'user', '777 Avenue, City', 'User Seven', '0889900112'),
('user8', 'password_hash_user8', 'user8@example.com', 'user', '888 Boulevard, City', 'User Eight', '0990011223'),
('user9', 'password_hash_user9', 'user9@example.com', 'user', '999 Avenue, Town', 'User Nine', '0112233445'),
('user10', 'password_hash_user10', 'user10@example.com', 'user', '101 Lane, Village', 'User Ten', '0223344556');





-- Khóa học Yoga
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach A', 'Yoga', 'Khóa học yoga giúp tăng cường sự dẻo dai và giảm căng thẳng.', 12,
'Tăng cường sự dẻo dai, linh hoạt, giảm căng thẳng, cải thiện hô hấp và tâm trí.',
'Các tư thế yoga (asana), bài tập thở (pranayama), và thiền.',
'Dinh dưỡng cân bằng, ưu tiên thực phẩm giàu chất xơ, ít đường và các loại thảo mộc giúp thư giãn.');

-- Khóa học Tăng cân
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach B', 'Tăng cân', 'Khóa học giúp người tập tăng cân một cách lành mạnh và tăng khối lượng cơ.', 8,
'Giúp người tập tăng cân một cách lành mạnh, tăng khối lượng cơ.',
'Tập trung vào việc tập luyện với tạ, các bài tập toàn thân như squat, deadlift, bench press.',
'Tăng cường calo, bổ sung protein chất lượng cao, thực phẩm giàu tinh bột và chất béo lành mạnh.');

-- Khóa học Giảm cân
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach C', 'Giảm cân', 'Khóa học giúp người tập giảm cân hiệu quả và an toàn.', 10,
'Giảm cân hiệu quả và an toàn.',
'Các bài tập cardio, HIIT, và bài tập đốt mỡ chuyên sâu.',
'Dinh dưỡng thấp calo, ưu tiên protein và rau xanh, giảm thiểu tinh bột và đường.');

-- Khóa học Bodybuilding
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach D', 'Bodybuilding', 'Khóa học xây dựng cơ bắp và cải thiện sức mạnh.', 16,
'Xây dựng cơ bắp, cải thiện sức mạnh và hình thể.',
'Các bài tập nâng tạ chuyên sâu như biceps curl, bench press, pull-ups, tập từng nhóm cơ cụ thể.',
'Dinh dưỡng cao protein, bổ sung các bữa phụ giàu calo để hỗ trợ phục hồi và phát triển cơ.');

-- Khóa tập sức bền
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach E', 'Sức bền', 'Khóa học tập trung vào việc tăng cường sức bền cơ thể.', 12,
'Tăng cường sức bền cơ thể, giúp cơ thể duy trì hoạt động lâu dài.',
'Chạy dài, đạp xe, bơi lội, các bài tập tim mạch kéo dài.',
'Dinh dưỡng giàu carb phức hợp và chất xơ, bổ sung điện giải và nước để duy trì năng lượng.');

-- Khóa học Functional Training
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach F', 'Functional Training', 'Khóa học giúp tăng cường sự ổn định và chức năng cơ thể.', 10,
'Tăng cường sự ổn định và chức năng toàn cơ thể, giúp hỗ trợ các hoạt động hàng ngày.',
'Các bài tập như kettlebell swings, lunges, push-ups, sử dụng dây TRX.',
'Dinh dưỡng đa dạng, ưu tiên thực phẩm nguyên chất, cân bằng giữa protein, carb và chất béo lành mạnh.');

-- Khóa học Kickboxing/Boxing Fitness
INSERT INTO courses (coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan)
VALUES 
('Coach G', 'Kickboxing/Boxing Fitness', 'Khóa học giúp cải thiện sự nhanh nhẹn, sức mạnh và sự phản xạ.', 8,
'Cải thiện sự nhanh nhẹn, sức mạnh và sự phản xạ, giảm stress.',
'Các động tác đấm, đá, phản xạ, cùng với các bài tập cardio.',
'Dinh dưỡng giàu protein, bữa ăn nhẹ trước tập và thực phẩm giàu năng lượng để hỗ trợ phản xạ nhanh.');



INSERT INTO coach (user_id, subject_area, years_of_experience, biography) VALUES
(2, 'Fitness', 5, 'Experienced fitness coach specializing in weight training and nutrition.'),
(3, 'Yoga', 10, 'Certified yoga instructor with a focus on holistic health and wellness.'),
(4, 'Cardio', 7, 'Expert in cardio exercises and endurance training, dedicated to improving heart health.'),
(5, 'Pilates', 8, 'Specialist in pilates and flexibility training, passionate about helping clients improve posture and core strength.');
