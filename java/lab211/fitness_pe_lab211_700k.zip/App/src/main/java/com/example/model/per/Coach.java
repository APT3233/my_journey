package com.example.model.per;


public class Coach extends Individual {
    private String userHandle;
    private String passHandle;
    private String subjectArea;
    private String yearsOfExperience;
    private String role;
    private String biography;

    public Coach() {
        super();
    }

    public Coach(String personId, String name, String contactNumber, String emailAddress, String location, String userHandle, String secretCode, String subjectArea, String yearsOfExperience, String role, String biography) {
        super(personId, emailAddress, location);
        this.userHandle = userHandle;
        this.passHandle = secretCode;
        this.subjectArea = subjectArea;
        this.yearsOfExperience = yearsOfExperience;
        this.role = role;
        this.biography = biography;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public String getUserHandle() {
        return userHandle;
    }

    public void setUserHandle(String userHandle) {
        this.userHandle = userHandle;
    }

    public String getSecretCode() {
        return passHandle;
    }

    public void setSecretCode(String secretCode) {
        this.passHandle = secretCode;
    }

    public String getSubjectArea() {
        return subjectArea;
    }
    public void setPassHandle(String passHandle) {
        this.passHandle = passHandle;
    }
    
    public void setSubjectArea(String subjectArea) {
        this.subjectArea = subjectArea;
    }

    public String getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(String yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getrole() {
        return role;
    }

    public void setrole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return String.format(
            "| %-10s | %-15s | %-15s | %-20s | %-15s | %-20s | %-15s | %-10s | %-70s ",
            getPersonId() != null ? getPersonId() : "N/A",        
            getName() != null ? getName() : "N/A",                 
            userHandle != null ? userHandle : "N/A",               
            getEmailAddress() != null ? getEmailAddress() : "N/A",
            getContactNumber() != null ? getContactNumber() : "N/A", 
            getLocation() != null ? getLocation() : "N/A",        
            subjectArea != null ? subjectArea : "N/A",             
            yearsOfExperience != null ? yearsOfExperience : "N/A", 
            biography != null ? biography : "N/A"                  
        );
    }

}
