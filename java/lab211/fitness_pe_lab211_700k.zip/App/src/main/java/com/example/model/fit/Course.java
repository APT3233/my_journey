package com.example.model.fit;

public class Course {
    private int courseId;
    private String coachName;
    private String courseName;
    private String description;
    private int durationWeeks;
    private String goal;
    private String exercises;
    private String nutritionPlan;

    public Course() {

    }   

    

    public Course(int courseId, String coachName, String courseName, String description, int durationWeeks,
                  String goal, String exercises, String nutritionPlan) {
        this.courseId = courseId;
        this.coachName = coachName;
        this.courseName = courseName;
        this.description = description;
        this.durationWeeks = durationWeeks;
        this.goal = goal;
        this.exercises = exercises;
        this.nutritionPlan = nutritionPlan;
    }


    public String getCoachName() {
        return coachName;
    }

    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public void setDurationWeeks(int durationWeeks) {
        this.durationWeeks = durationWeeks;
    }
    public void setExercises(String exercises) {
        this.exercises = exercises;
    }
    public void setGoal(String goal) {
        this.goal = goal;
    }
    public void setNutritionPlan(String nutritionPlan) {
        this.nutritionPlan = nutritionPlan;
    }
    public int getCourseId() {
        return courseId;
    }
    public String getCourseName() {
        return courseName;
    }
    public String getDescription() {
        return description;
    }
    public int getDurationWeeks() {
        return durationWeeks;
    }
    public String getExercises() {
        return exercises;
    }
    public String getGoal() {
        return goal;
    }
    public String getNutritionPlan() {
        return nutritionPlan;
    }
    @Override
    public String toString() {
        return String.format(
            "+--------------------------------------------------- Courese -------------------------------------------------------------------------------\n" +
            "| \033[1;36mCourse ID       : %-10d\n\033[0m" +
            "| \033[1;36mCoach Name      : %-20s\n\033[0m" +
            "| \033[1;36mCourse Name     : %-20s\n\033[0m" +
            "| \033[1;36mDescription     : %-30s\n\033[0m" +
            "| \033[1;36mDuration (weeks): %-10d\n\033[0m" +
            "| \033[1;36mGoal            : %-30s\n\033[0m" +
            "| \033[1;36mExercises       : %-30s\n\033[0m" +
            "| \033[1;36mNutrition Plan  : %-30s\n\033[0m" +
            "+-------------------------------------------------------------------------------------------------------------------------------------------\n",
            courseId,
            coachName,
            courseName,
            description,
            durationWeeks,
            goal,
            exercises,
            nutritionPlan
        );
    }

}
