package com.example.model.per;


public class User extends Individual {
    private String userName;
    private String passwd;
    private String role;
    private String createDate;

    public User() {
        super();
    }

    

    public User(String id, String userName, String passwd, String email, String role, String address, String phone) {
        super(id, email, address, phone, phone);
        this.userName = userName;
        this.passwd = passwd;
        this.role = role;
    }    
    public User(String id, String username, String fullname, String email, String phone, String address) {
        super(id, address, email, phone, address);
        this.userName = username;
    }

    public String getuserName() {
        return userName;
    }
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }
    public String getCreateDate() {
        return createDate;
    }
    public void setuserName(String userName) {
        this.userName = userName;
    }

    public String getpasswd() {
        return passwd;
    }

    public void setpasswd(String passwd) {
        this.passwd = passwd;
    }


    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    

   
    
    

    @Override
    public String toString() {
        return String.format(
            "| %-5s | %-15s | %-20s | %-20s | %-15s | %-20s | %-10s |",
            getPersonId() != null ? getPersonId() : "N/A",       
            userName != null ? userName : "N/A",                   
            getName() != null ? getName() : "N/A",                
            getEmailAddress() != null ? getEmailAddress() : "N/A",  
            getContactNumber() != null ? getContactNumber() : "N/A",
            getLocation() != null ? getLocation() : "N/A",      
            role != null ? role : "N/A"                      
        );
    }



}