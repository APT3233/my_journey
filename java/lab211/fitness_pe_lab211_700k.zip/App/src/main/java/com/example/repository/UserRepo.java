package com.example.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.example.controller.LoginController;
import com.example.model.per.User;
import com.example.utility.Db;
import com.example.validation.Validation;

public class UserRepo {
    
    public int login(String username, String password) {
        String sql = "SELECT role FROM users WHERE username = ? AND password = ?";

        try (Connection conn = Db.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password); 

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                if ("admin".equalsIgnoreCase(role)) {
                    return 2; // Admin
                } else if ("user".equalsIgnoreCase(role)) {
                    return 1; // User
                }
            }
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Đăng nhập thất bại: " + e.getMessage());
        }
        return -1;
    }
    
    public int signUp(String username, String password, String email, String role, String fullname, String address, String phone) {
        String sql = "INSERT INTO users (username, password, email, role, fullname, address, phone) VALUES (?, ?, ?, ?, ?, ?, ?)";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, email);
            stmt.setString(4, role);
            stmt.setString(5, fullname);
            stmt.setString(6, address);
            stmt.setString(7, phone);
    
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                return 1; // Đăng ký thành công
            }
    
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Đăng ký thất bại: " + e.getMessage());
            return -1; // Đăng ký thất bại
        }
        return -1; 
    }

    // add 
    public int add(User entity) throws SQLException {
        try (Connection connection = Db.getConnection    ()) {
            if (connection == null || connection.isClosed()) {
                Validation.displayMessage("\t[-] Failed to establish or maintain connection to the database.");
                return -1;
            }

            String sql = "INSERT INTO users (username, password, email, role, address) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, entity.getuserName());
                statement.setString(2, entity.getpasswd());
                statement.setString(3, entity.getEmailAddress());
                statement.setString(4, entity.getRole());
                statement.setString(5, entity.getLocation());

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    Validation.displayMessage("\t[+] User " + entity.getName() + " was added successfully!");
                    return rowsInserted;
                } else {
                    Validation.displayMessage("\t[-] No rows were inserted.");
                    return -1;
                }
            } catch (SQLException e) {
                Validation.displayMessage("\t[-] Error occurred while adding user: " + e.getMessage()
                        + " SQLState: " + e.getSQLState()
                        + " ErrorCode: " + e.getErrorCode());
                return -1;
            }
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error occurred while establishing connection: " + e.getMessage());
            return -1;
        }
    }
    
    
    public List<User> getAllUsers() throws SQLException {
        List<User> users = new ArrayList<>();

        try (Connection connection = Db.getConnection()) {
            if (connection == null || connection.isClosed()) {
                Validation.displayMessage("\t[-] Failed to establish or maintain connection to the database.");
                return null;
            }

            String sql = "SELECT * FROM users WHERE role = 'user'";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        User user = new User();
                        user.setPersonId(resultSet.getString("id"));
                        user.setuserName(resultSet.getString("username"));
                        user.setName(resultSet.getString("fullname"));
                        user.setEmailAddress(resultSet.getString("email"));
                        user.setContactNumber(resultSet.getString("phone"));
                        user.setLocation(resultSet.getString("address"));
                        user.setRole(resultSet.getString("role"));

                        users.add(user);
                    }
                    if (!users.isEmpty()) {
                        return users;
                    }
                } catch (SQLException e) {
                    Validation.displayMessage("\t[-] Error occurred while retrieving users: " + e.getMessage()
                            + " SQLState: " + e.getSQLState()
                            + " ErrorCode: " + e.getErrorCode());
                    return null;
                }
            } catch (SQLException e) {
                Validation.displayMessage("\t[-] Error occurred while preparing statement: " + e.getMessage());
                return null;
            }
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error occurred while establishing connection: " + e.getMessage());
            return null;
        }

        return users;
    }

    public User getUserByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";
        User user = null;
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, username);
    
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    user = new User();
                    user.setPersonId(rs.getString("id"));
                    user.setuserName(rs.getString("username"));
                    user.setName(rs.getString("fullname"));
                    user.setEmailAddress(rs.getString("email"));
                    user.setContactNumber(rs.getString("phone"));
                    user.setLocation(rs.getString("address"));
                    user.setRole(rs.getString("role"));
                    user.setCreateDate(rs.getTimestamp("created_at").toLocalDateTime().toString());
                }
            }
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error retrieving user profile: " + e.getMessage());
        }

        return user;
    }

    public int sendReport(String res) {
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO reports (user_name, response) VALUES (?, ?)")) {
            
            stmt.setString(1, LoginController.USERNAME); 
            stmt.setString(2, res); 
    
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) 
                return 1;  
            else 
                return 0; 
            
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error saving report to the database: " + e.getMessage());
            return -1; 
        }
    }
    
    public int removeByUsername(String username) {
        String sql = "DELETE FROM users WHERE username = ?";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, username);
    
            return stmt.executeUpdate();
    
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error removing user: " + e.getMessage());
            return -1; 
        }
    }
    public boolean isUserExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;  
            }
        } catch (SQLException e) {
        }
        
        return false; 
    }
    public boolean updateUserProfile(String username, String fullname, String email, String phone, String address) {
        String sql = "UPDATE users SET fullname = ?, email = ?, phone = ?, address = ? WHERE username = ?";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, fullname);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.setString(4, address);
            stmt.setString(5, username);
    
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
    
        } catch (SQLException e) {
            Validation.displayMessage("\t[-] Error updating user profile: " + e.getMessage());
            return false;
        }
    }
    
    
}
