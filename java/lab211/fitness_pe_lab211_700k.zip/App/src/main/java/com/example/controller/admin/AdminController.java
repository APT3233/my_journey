package com.example.controller.admin;

import java.sql.SQLException;
import java.util.List;

import com.example.repository.CoachRepo;
import com.example.repository.UserRepo;
import com.example.validation.Validation;
import com.example.repository.CourseRepo;
import com.example.view.Menu;
import com.example.model.fit.Course;
import com.example.model.per.Coach;
import com.example.model.per.User;

public class AdminController extends Menu {

    private UserRepo userRepo = new UserRepo();
    private CoachRepo coachRepo = new CoachRepo();
    private CourseRepo courseRepo = new CourseRepo();
    private static String titleAdmin = 
            "\033[1;35m\t   _       _           _       \n" +
            "\t  /_\\   __| |_ __ ___ (_)_ __  \n" +
            "\t //_\\\\ / _` | '_ ` _ \\| | '_ \\ \n" +
            "\t/  _  \\ (_| | | | | | | | | | |\n" +
            "\t\\_/ \\_/\\__,_|_| |_| |_|_|_| |_|\033[0m";

    private static String[] choicesAdm = {
            "Display all users", 
            "Display all coaches", 
            "Display all courses", 
            "Modify data", 
    };

    public AdminController() {
        super(titleAdmin, choicesAdm);
    }

    @Override
    public void execute(int ch) {
        switch (ch) {
            case 1:
                try {
                    displayAllUsers();
                } catch (Exception e) {}
                break;
            case 2:
                try{
                    displayAllCoaches();
                }catch(Exception e) {}
                break;
            case 3:
                try {
                    displayAllCourses();
                } catch (Exception e) {}
                break;
            case 4:
                modifyData();
                break;
            default:
                Validation.displayMessage("\t[-] Invalid choice, please select a valid option.");
                break;
        }
    }

    private void displayAllUsers() throws SQLException {
        Validation.displayMessage("\t\t--------> Displaying all users <-----------\n");
        Validation.displayMessage(String.format(
            "\033[1;32m| %-5s | %-15s | %-20s | %-20s | %-15s | %-20s | %-10s |",
            "ID", "Username", "Full Name", "Email", "Phone", "Address", "Role"
        ));
        Validation.displayMessage("+-------+-----------------+----------------------+----------------------+-----------------+----------------------+------------+");

        List<User> listUsers = userRepo.getAllUsers();
        for(User x : listUsers)
            Validation.displayMessage(x.toString());
        Validation.displayMessage("+------------------------------------------------------------- End -----------------------------------------------------------+\033[0m");
        Validation.pressKey("\t[.] Press anykey to continue. ");

    }

    private void displayAllCoaches() throws SQLException {
        Validation.displayMessage("--------> Displaying all coaches <-----------\n");
        Validation.displayMessage(String.format(
            "\033[1;32m| %-10s | %-15s | %-15s | %-20s | %-15s | %-20s | %-15s | %-10s | %-40s ",
            "ID", "Name", "Username", "Email", "Phone", "Address", "Subject Area", "Experience", "Biography"
        ));
        Validation.displayMessage("+------------+-----------------+-----------------+----------------------+-----------------+----------------------+-----------------+------------+---------------------------------------------------------------------------------");
        List<Coach> listCoach = coachRepo.getAllCoachs();
        for(Coach x : listCoach)
            Validation.displayMessage(x.toString());
        Validation.displayMessage("---------------------------------------------- End ----------------------------------------------\033[0m");
        Validation.pressKey("\t[.] Press anykey to continue. ");

    }

    private void displayAllCourses() throws SQLException {
        Validation.displayMessage("--------> Displaying all courses <-----------\n\033[1;32m");
        List<Course> listCourses = courseRepo.getAllCourses();
        for(Course x : listCourses)
            Validation.displayMessage(x.toString());
        Validation.displayMessage("---------------------------------------------- End ----------------------------------------------\033[0m");
        Validation.pressKey("\t[.] Press anykey to continue. ");

    }

    private void modifyData() {
        final String[] choicesMody = {"Remove User", "Remove Course", "Remove Coach"};
        Menu subMenu = new Menu(titleAdmin, choicesMody) {
    
            @Override
            public void execute(int choice) {
                switch (choice) {
                    case 1:
                        removeUser();
                        break;
                    case 2:
                        removeCourse();
                        break;
                    case 3:
                        removeCoach();
                        break;
                    default:
                        Validation.displayMessage("\t\033[1;31m[-] Invalid choice. Please try again.\033[0m");
                }
            }
        };
    
        subMenu.run();
    }
    

    public void removeUser() {
        Validation.displayMessage("====================== Remove User ======================");
        String username = Validation.getString("[+] Username to remove: ");
    
        int confirm = Validation.confirm("[.] Are you sure you want to remove user " + username + "?");
        if (confirm != 1) {
            Validation.displayMessage("\t\033[1;31m[-] Operation cancelled.\033[0m");
            return;
        }
    
        int result = userRepo.removeByUsername(username);
        if (result > 0) {
            Validation.displayMessage("\t\033[1;32m[+] User " + username + " has been successfully removed.\033[0m");
            Validation.pressKey("\t[.] Press anykey to continue. ");

        } else {
            Validation.displayMessage("\t\033[1;31m[-] Failed to remove user. User " + username + " may not exist.\033[0m");
            
        }
    }
    
    public void removeCourse() {
        Validation.displayMessage("====================== Remove Course ======================");
        int courseId = Validation.getIntegerFor("[+] Course ID to remove: ");
    
        int confirm = Validation.confirm("[.] Are you sure you want to remove course with ID " + courseId + "?");
        if (confirm != 1) {
            Validation.displayMessage("\t\033[1;31m[-] Operation cancelled.\033[0m");
            return;
        }
    
        int result = courseRepo.removeByCourseId(courseId);
        if (result > 0) {
            Validation.displayMessage("\t\033[1;32m[+] Course with ID " + courseId + " has been successfully removed.\033[0m");
            Validation.pressKey("\t[.] Press anykey to continue. ");

        } else {
            Validation.displayMessage("\t\033[1;31m[-] Failed to remove course. Course with ID " + courseId + " may not exist.\033[0m");
        }
    }
    
    public void removeCoach() {
        Validation.displayMessage("====================== Remove Coach =====================");
        String coachName = Validation.getString("[+] Coach name to remove: ");
    
        int confirm = Validation.confirm("Are you sure you want to remove coach " + coachName + "?");
        if (confirm != 1) {
            Validation.displayMessage("\t\033[1;31m[.] Operation cancelled.\033[0m");
            return;
        }
    
        int result = coachRepo.removeByCoachName(coachName);
        if (result > 0) {
            Validation.displayMessage("\t\033[1;32m[+] Coach " + coachName + " has been successfully removed.\033[0m");
            Validation.pressKey("\t[.] Press anykey to continue. ");

        } else {
            Validation.displayMessage("\t\033[1;31m[-] Failed to remove coach. Coach " + coachName + " may not exist.\033[0m");
        }
    }
    


   
}
