package com.example;

import com.example.controller.LoginController;
import com.example.utility.Db;
import com.example.utility.sys;

/**
 * Main App
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
        new App().start();
    }


    
    public void start() throws Exception
    {
        Db.testConnection();
        sys.clear();
        LoginController login = new LoginController();
        login.run();
    }
}
