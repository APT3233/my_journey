package com.example.validation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public  class Validation {

    static Scanner keyboard = new Scanner(System.in);

    public Validation() {
    }

    public static void displayMessage(String mess) {
        System.out.println(mess);
    }

    public static String getString(String msg){
        System.out.print(msg);
        return keyboard.nextLine().trim();
    }

    public static int getIntegerFor(String mess) {
        int a = -1;
        boolean ch = true;
        do {
            try {
                System.out.print(mess);
                
                a = Integer.parseInt(keyboard.nextLine());
                ch = false;
            } catch (Exception e) {
                System.out.println("   ==>  Incorrect format of " + mess);
            }   
        } while (ch);
        return a;
    }
    public static String getValidPhoneNumber() {
        String phone;
        do {
            phone = Validation.getString("\t[+] PhoneNumber: ");
            
            if (!phone.matches("^0\\d{9}$")) { 
                Validation.displayMessage("\t\033[1;31m[-] Invalid phone number. Please enter a 10-digit phone number starting with 0.\033[0m\n");
                phone = null; 
            }
            
        } while (phone == null);
        
        return phone;
    }
    
    public static int confirm(String msg) {
        System.out.print(msg);
        System.out.print("\n==> ");
        String input = keyboard.nextLine().trim();
        
        if ("y".equalsIgnoreCase(input)) {
            return 1;
        } else {
            return 0;
        }
    }

    public static double getDoubleFor(String mess) {
        boolean ch = true;
        double a = -1;
        do {
            try {
                System.out.print(mess);
                a = Double.parseDouble(keyboard.nextLine());
                ch = false;
            } catch (Exception e) {
                System.out.println("   ==>  Incorrect format of " + mess);
            }
        } while (ch);
        return a;
    }

    public static boolean getBooleanFor(String mess) {
        boolean ch = true;
        boolean a = true;
        do {
            try {
                System.out.print(mess);
                a = Boolean.parseBoolean(keyboard.nextLine());
                ch = false;
            } catch (Exception e) {
                System.out.println("   ==>  Incorrect format of " + mess + " (true or false)");
            }
        } while (ch);
        return a;
    }

    public static LocalDate getDateFor(String mess) {
        boolean ch = true;
        LocalDate date = null;
        do {
            System.out.print(mess);
            String dateString = keyboard.nextLine();

            try {
                String[] parts = dateString.split("/");
                if (parts[0].length() == 1) {
                    parts[0] = "0" + parts[0];
                }
                if (parts[1].length() == 1) {
                    parts[1] = "0" + parts[1];
                }
                dateString = String.join("/", parts);

                date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                ch = false;
            } catch (Exception e) {
                System.out.println("   ==>  The correct date format is: (dd/mm/yyyy)");
            }
        } while (ch);
        return date;
    }

    public static String getStringFor(String mess) {
        System.out.print(mess);
        return keyboard.nextLine();
    }


    public static String checkUserName(String in, String err) {
        try {
            if (in == null || in.isEmpty()) {
                return null;
            }
            String regex = "^[a-zA-Z][a-zA-Z0-9._-]{2,}$";
            if (in.matches(regex)) {
                return in;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }
    public static String checkPass(String in, String err) {
        if (in == null || in.length() < 8) {
            return null;
        }
        String regex = "^(?=.*[0-9])(?=.*[a-zA-Z]).{8,}$";
        if (in.matches(regex)) {
            return in;
        } else {
            return null;
        }
    }
    public static String checkEmail(String in, String err) {
        if (in == null || in.isEmpty()) {
            return null;
        }
        String regex = "^[\\w-\\.]+@(fpt\\.edu\\.vn|gmail\\.com)$";
        if (in.matches(regex)) {
            return in;
        } else {
            return null;
        }
    }
    public static void pressKey(String msg){
        displayMessage(msg);
        String tmp = keyboard.nextLine();
        return;
    }
}
