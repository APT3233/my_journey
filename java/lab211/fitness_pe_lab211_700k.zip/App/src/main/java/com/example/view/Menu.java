package com.example.view;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public abstract class Menu {
    protected String title;
    protected ArrayList<String> options;
    private static Stack<Menu> menuStack = new Stack<>();
    private static Scanner scanner = new Scanner(System.in);

    public Menu() {
    }

    public Menu(String title, String[] optionsArray) {
        this.title = title;
        this.options = new ArrayList<>();
        for (String option : optionsArray) {
            this.options.add(option);
        }
    }

    public static void navigateTo(Menu newMenu) {
        if (!menuStack.isEmpty()) {
            menuStack.peek().closeMenu();
        }
        menuStack.push(newMenu);
        newMenu.showMenu();
    }

    public static void goBack() {
        if (menuStack.size() > 1) {
            menuStack.pop().closeMenu(); 
            menuStack.peek().showMenu();  
        } else {
            System.out.println("Đây là menu gốc. Không thể quay lại.");
        }
    }

    public void showMenu() {
        display();
        run();
    }

    public void closeMenu() {
        System.out.println("Exiting " + title + "...");
    }

    public void display() {
        System.out.println(title);
        System.out.println("---------------------------------");
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
        System.out.println("---------------------------------");
    }

    public int getSelected() {
        display();
        System.out.print("Enter selection: ");
        System.out.print("\n==> ");
        while (!scanner.hasNextInt()) {
            System.out.print("\t[-] Invalid input. Please enter a number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    public abstract void execute(int choice);

    public void run() {
        while (true) {
            try {
                int choice = getSelected();
                if (choice > 0 ) {
                    execute(choice);
                } 
                else if(choice==0){
                    System.out.println("\t[-] Invalid choice. Exiting menu.");
                    break;
                }
                else {
                    System.out.println("\t[-] Invalid choice. Please try again.");
                    break;
                }    
            } catch (Exception e) {}
        }
    }
}
