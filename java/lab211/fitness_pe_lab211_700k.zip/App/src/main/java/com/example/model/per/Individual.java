package com.example.model.per;

public abstract class Individual {
    private String personId;
    private String name;
    private String contactNumber;
    private String emailAddress;
    private String location;

    public Individual() {}

    public Individual(String personId, String emailAddress, String location) {
        this.personId = personId;
        this.name = null;
        this.contactNumber = null;
        this.emailAddress = emailAddress;
        this.location = location;
    }

    public Individual(String personId, String location, String emailAddress, String name, String contactNumber) {
        this.personId = personId;
        this.location = location;
        this.emailAddress = emailAddress;
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String id) {
        this.personId = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
