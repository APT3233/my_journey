package com.example.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.model.per.Coach;
import com.example.utility.Db;

public class CoachRepo {
 
    public List<Coach> getAllCoachs() {
        List<Coach> coaches = new ArrayList<>();
        String sql = "SELECT u.id AS user_id, u.username, u.email, u.phone, u.address, " +
                     "c.subject_area, c.years_of_experience, c.biography " +
                     "FROM users u " +
                     "JOIN coach c ON u.id = c.user_id " +
                     "WHERE u.role = 'coach'";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
    
            while (rs.next()) {
                String userId = rs.getString("user_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String address = rs.getString("address");
                String subjectArea = rs.getString("subject_area");
                int yearsOfExperience = rs.getInt("years_of_experience");
                String biography = rs.getString("biography");
    
                Coach coach = new Coach();
                coach.setUserHandle(username);           
                coach.setSecretCode("");            
                coach.setSubjectArea(subjectArea);        
                coach.setYearsOfExperience(String.valueOf(yearsOfExperience)); 
                coach.setBiography(biography);            
                coach.setPersonId(userId);                      
                coach.setEmailAddress(email);             
                coach.setContactNumber(phone);           
                coach.setLocation(address);               
                coach.setrole("coach");                  
    
                coaches.add(coach);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving coaches: " + e.getMessage());
        }
    
        return coaches;
    }
    

    public int removeByCoachName(String coachName) {
        String sql = "DELETE FROM users WHERE username = ? AND role = 'coach'";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, coachName);
    
            return stmt.executeUpdate();
    
        } catch (SQLException e) {
            System.out.println("\t[-] Error removing coach: " + e.getMessage());
            return -1; 
        }
    }
    

}
