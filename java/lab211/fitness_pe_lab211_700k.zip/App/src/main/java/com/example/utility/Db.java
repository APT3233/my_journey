package com.example.utility;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Db - Quản lý kết nối cơ sở dữ liệu
 */
public class Db {

    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://103.186.101.33:3306/fitness_pe?useSSL=true&serverTimezone=UTC";
    private static final String USER = "user1";
    private static final String PASSWORD = "password321";
    private static final int MAX_POOL_SIZE = 15;

    private static HikariDataSource dataSource = initializeDataSource();

    public static void testConnection() {
        try (Connection connection = getConnection()) {
            if (connection != null && !connection.isClosed()) {
                System.out.println("Kết nối thành công đến cơ sở dữ liệu!");
            } else {
                System.out.println("Không thể kết nối đến cơ sở dữ liệu.");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối: " + e.getMessage());
        }
    }

    private static HikariConfig configureHikari() {
        HikariConfig config = new HikariConfig();
        config.setDriverClassName(DRIVER);
        config.setJdbcUrl(URL);
        config.setUsername(USER);
        config.setPassword(PASSWORD);
        config.setMaximumPoolSize(MAX_POOL_SIZE);
        config.setIdleTimeout(60000);
        return config;
    }


    private static HikariDataSource initializeDataSource() {
        return new HikariDataSource(configureHikari());
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}
