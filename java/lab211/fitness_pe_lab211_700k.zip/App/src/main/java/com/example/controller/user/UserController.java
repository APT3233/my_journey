package com.example.controller.user;

import java.sql.SQLException;
import java.util.List;

import com.example.controller.LoginController;
import com.example.model.fit.Course;
import com.example.repository.CoachRepo;
import com.example.repository.CourseRepo;
import com.example.repository.UserRepo;
import com.example.utility.sys;
import com.example.validation.Validation;
import com.example.view.Menu;

public class UserController extends Menu {

    private UserRepo userRepo = new UserRepo();
    private CoachRepo coachRepo = new CoachRepo();
    private CourseRepo courseRepo = new CourseRepo();
    

    private static String titleUser = "\n\033[1;35m" +
            "\tdb    db .d8888. d88888b d8888b. \n" +
            "\t88    88 88'  YP 88'     88  `8D \n" +
            "\t88    88 `8bo.   88ooooo 88oobY' \n" +
            "\t88    88   `Y8b. 88~~~~~ 88`8b   \n" +
            "\t88b  d88 db   8D 88.     88 `88. \n" +
            "\t~Y8888P' `8888Y' Y88888P 88   YD \n" +
            "                                 \033[0m";
    
    private static String[] choicesUser = {
            "Overview", 
            "My Plan", 
            "Profile", 
            "Report",
    };

    public UserController() {
        super(titleUser, choicesUser);
    }

    @Override
    public void execute(int choice) {
        switch (choice) {
            case 1:
                try {
                    showOverview();
                } catch (Exception e) {}
                break;
            case 2:
                try {
                    showMyPlan();
                } catch (Exception e) {}
                break;
            case 3:
                try {
                    showProfile();
                } catch (Exception e) {}
                break;
            case 4:
                showReport();
                break;
            default:
                Validation.displayMessage("\t\033[1;31m[-] Invalid choice, please select a valid option.\033[0m");
                break;
        }
    }

    private void showOverview() throws SQLException, InterruptedException {
        Validation.displayMessage("\n\t\033[1;36mDisplaying overview...");
            List<Course> listCourses = courseRepo.getAllCourses();
        if (listCourses.isEmpty()) {
            Validation.displayMessage("\t\033[1;31m[-] No courses available.\033[0m");
            return;
        }
        for (Course course : listCourses) {
            Validation.displayMessage(course.toString());
        }
        Validation.displayMessage("\033[0m");
        Course orderCourse = null;
    
        while (orderCourse == null) {
            Validation.displayMessage("[.] Which course do you want to choose?");
            int choice = Validation.getIntegerFor("[+] You select: ");
            Validation.displayMessage("\tVerifying...");
    
            orderCourse = courseRepo.getCourseById(choice);
            if (orderCourse == null) {
                Validation.displayMessage("\t\033[1;31m[-] Your selection is not correct. Please try again!\033[0m");
            }
            Validation.displayMessage(orderCourse.toString());
        }
    
        int confirm = Validation.confirm("Do you want to order course " + orderCourse.getCourseId() + " of coach " + orderCourse.getCoachName() + "?");
        if (confirm == 1) {
            boolean isAlreadyRegistered = courseRepo.isCourseRegisteredByUser(orderCourse.getCourseId(), LoginController.USERNAME);
            
            if (isAlreadyRegistered) {
                Validation.displayMessage("\t[+] You have already registered for this course: " + orderCourse.getCourseName());
            } else {
                int res = courseRepo.addRegistration(orderCourse.getCourseId(), orderCourse.getCourseName(), LoginController.USERNAME);
                if (res == 1) {
                    Validation.displayMessage("\t\033[1;32m[+] Registration successful for course: " + orderCourse.getCourseName()+ "\033[0m");
                    Validation.pressKey("\t[.] Press anykey to continue. ");

                } else {
                    Validation.displayMessage("\t\033[1;31m[-] Registration failed. Please try again.\033[0m");
                }
            }
        } else {
            Validation.displayMessage("\t\033[1;31m[-] Registration cancelled.\033[0m");
        }

    }
    
    

    private void showMyPlan() throws SQLException {
        sys.clear();
        Validation.displayMessage("Displaying user plan...");
    
        List<Course> registeredCourses = courseRepo.getRegisteredCoursesByUser(LoginController.USERNAME);
    
        if (registeredCourses.isEmpty()) {
            Validation.displayMessage("You have no courses registered.");
            return;
        }
    
        for (Course course : registeredCourses) {
            Validation.displayMessage(course.toString());
        }
        Validation.pressKey("\t[.] Press anykey to continue. ");
    }
    

    private void showProfile() throws SQLException {
        sys.clear();
        Validation.displayMessage("Displaying user profile...");
    
        com.example.model.per.User currentUser = userRepo.getUserByUsername(LoginController.USERNAME);
    
        if (currentUser == null) {
            Validation.displayMessage("User profile not found.");
            return;
        }
        Validation.displayMessage("-------------------------- PROFILE --------------------------------");
        Validation.displayMessage("\033[1;36m[+] User ID            : " + currentUser.getPersonId());
        Validation.displayMessage("[+] Username           : " + currentUser.getuserName());
        Validation.displayMessage("[+] Full Name          : " + currentUser.getName());
        Validation.displayMessage("[+] Email              : " + currentUser.getEmailAddress());
        Validation.displayMessage("[+] Phone              : " + currentUser.getContactNumber());
        Validation.displayMessage("[+] Address            : " + currentUser.getLocation());
        Validation.displayMessage("[+] Role               : " + currentUser.getRole());
        Validation.displayMessage("[+]Account Created On  : " + currentUser.getCreateDate());
        Validation.displayMessage("\033[0m-----------------------------------------------------------------\n");

        int checkUpdate = Validation.confirm("[.] Do you want to update profile[y/n] ?");
        if(checkUpdate==0){
            Validation.displayMessage("\t\033[1;31m[-] Update cancelled.\033[0m");
            Validation.pressKey("\t[.] Press anykey to continue. ");
            return;
        }
        
        Validation.displayMessage("\033[0m------------------------------- UPDATING ----------------------------------\n");
        String fullname = Validation.getString("\t[+] FullName: ");
        String email;
        do {
            email = Validation.checkEmail(Validation.getString("\t[+] Email: "), "\n\t[-] Wrong format email");
            if (email == null || email.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Email cannot be empty or incorrect format.\n\033[0m");
            }
        } while (email == null || email.trim().isEmpty());
        String phone = Validation.getValidPhoneNumber();
        String address = Validation.getString("\t[+] Address: ");
        
        int checkUpdate2 = Validation.confirm("\n[.] Last verify. Do you want to continue [y/n]?");
        if (checkUpdate2 == 0) {
            Validation.displayMessage("\t\033[1;31m[-] Update cancelled.\033[0m");
            Validation.pressKey("\t[.] Press any key to continue.");
            return;
        }
        boolean isUpdated = userRepo.updateUserProfile(LoginController.USERNAME, fullname, email, phone, address);
        if (isUpdated) 
            Validation.displayMessage("\t\033[1;32m[+] Profile updated successfully.\033[0m");
        else 
            Validation.displayMessage("\t\033[1;31m[-] Failed to update profile.\033[0m");
        
    
        Validation.pressKey("\t[.] Press any key to continue.");
    }
    

    private void showReport() {
        Validation.displayMessage("[.] REPORT FOR US...");
        
        String response = Validation.getString("==> Response: ");
    
        int res = userRepo.sendReport(response);
        if (res != 1) {
            Validation.displayMessage("Failed to submit the report. Please try again.");
            return;
        }
        
        Validation.displayMessage("\t033[1;32m[+]Report successfully submitted!\033[0m");
        Validation.pressKey("\t[.] Press anykey to continue. ");

    }
    


}
