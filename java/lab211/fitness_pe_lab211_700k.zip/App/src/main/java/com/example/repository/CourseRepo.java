package com.example.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.model.fit.Course;
import com.example.utility.Db;

public class CourseRepo {

    public List<Course> getAllCourses() throws SQLException {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM courses";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
    
            while (rs.next()) {
                Course course = new Course(); 
    
                course.setCourseId(rs.getInt("courses_id"));
                course.setCoachName(rs.getString("coach_name"));
                course.setCourseName(rs.getString("course_name"));
                course.setDescription(rs.getString("description"));
                course.setDurationWeeks(rs.getInt("duration_weeks"));
                course.setGoal(rs.getString("goal"));
                course.setExercises(rs.getString("exercises"));
                course.setNutritionPlan(rs.getString("nutrition_plan"));
    
                courses.add(course);
            }
        } catch (SQLException e) {
            System.out.println("\t[-] Error retrieving courses: " + e.getMessage());
        }
        return courses;
    }

    public Course getCourseById(int courseId) throws SQLException {
        String sql = "SELECT courses_id, coach_name, course_name, description, duration_weeks, goal, exercises, nutrition_plan, created_at FROM courses WHERE courses_id = ?";
        Course course = null;
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setInt(1, courseId);
    
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    course = new Course();
                    
                    course.setCourseId(rs.getInt("courses_id"));
                    course.setCoachName(rs.getString("coach_name"));
                    course.setCourseName(rs.getString("course_name"));
                    course.setDescription(rs.getString("description"));
                    course.setDurationWeeks(rs.getInt("duration_weeks"));
                    course.setGoal(rs.getString("goal"));
                    course.setExercises(rs.getString("exercises"));
                    course.setNutritionPlan(rs.getString("nutrition_plan"));
                }
            }
        } catch (SQLException e) {
            System.out.println("\t[-] Error retrieving course by ID: " + e.getMessage());
        }
        
        return course;
    }

    public int addRegistration(int courseId, String courseName, String userName) {
        String sql = "INSERT INTO registration (course_id, course_name, user_name) VALUES (?, ?, ?)";
        
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, courseId);
            stmt.setString(2, courseName);
            stmt.setString(3, userName);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("\t[+] Registration added successfully!");
                return 1;
            } else {
                System.out.println("\t[-] Failed to add registration.");
                return 0;
            }

        } catch (SQLException e) {
            System.out.println("\t[-] Error adding registration: " + e.getMessage());
            return 0;
        }
    }
    public List<Course> getRegisteredCoursesByUser(String userName) throws SQLException {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT r.course_id, r.course_name, r.user_name, c.description, c.duration_weeks, c.goal, c.exercises, c.nutrition_plan " +
                     "FROM registration r " +
                     "JOIN courses c ON r.course_id = c.courses_id " +
                     "WHERE r.user_name = ?";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setString(1, userName);
    
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course();
                    course.setCourseId(rs.getInt("course_id"));
                    course.setCourseName(rs.getString("course_name"));
                    course.setDescription(rs.getString("description"));
                    course.setDurationWeeks(rs.getInt("duration_weeks"));
                    course.setGoal(rs.getString("goal"));
                    course.setExercises(rs.getString("exercises"));
                    course.setNutritionPlan(rs.getString("nutrition_plan"));
    
                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.out.println("\\t[-] Error retrieving registered courses: " + e.getMessage());
        }
    
        return courses;
    }

    public boolean isCourseRegisteredByUser(int courseId, String userName) throws SQLException {
        String sql = "SELECT 1 FROM registration WHERE course_id = ? AND user_name = ?";
        boolean isRegistered = false;
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setInt(1, courseId);
            stmt.setString(2, userName);
    
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    isRegistered = true; // Có bản ghi trùng khớp
                }
            }
        } catch (SQLException e) {
            System.out.println("\t[-] Error checking course registration: " + e.getMessage());
        }
    
        return isRegistered;
    }
    
    public int removeByCourseId(int courseId) {
        String sql = "DELETE FROM courses WHERE courses_id = ?";
    
        try (Connection conn = Db.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setInt(1, courseId);
    
            return stmt.executeUpdate();
    
        } catch (SQLException e) {
            System.out.println("\t[-] Error removing course: " + e.getMessage());
            return -1;
        }
    }
    
    
}
