package com.example.controller;



import java.io.Console;

import com.example.controller.admin.AdminController;
import com.example.controller.user.UserController;
import com.example.repository.UserRepo;
import com.example.utility.sys;
import com.example.validation.Validation;

import com.example.view.Menu;

public class LoginController extends Menu {
    
    private static String myTitle = 
            "\033[1;35m\t___________.__  __                                 _____                 \n" +
            "\t\\_   _____/|__|/  |_  ____   ____   ______ ______ /  _  \\ ______ ______  \n" +
            "\t |    __)  |  \\   __\\/    \\_/ __ \\ /  ___//  ___//  /_\\  \\\\____ \\\\____ \\ \n" +
            "\t |     \\   |  ||  | |   |  \\  ___/ \\___ \\ \\___ \\/    |    \\  |_> >  |_> >\n" +
            "\t \\___  /   |__||__| |___|  /\\___  >____  >____  >____|__  /   __/|   __/ \n" +
            "\t     \\/                  \\/     \\/     \\/     \\/        \\/|__|   |__|    \n\033[0m";

    private static String[] choices = {"Login", "Sign Up", "Exit"};
    private UserRepo userRepo = new UserRepo();
    public LoginController() throws Exception{
        super(myTitle, choices);
    }

    public static String USERNAME;

    @Override
    public void execute(int ch){
        switch (ch) {
            case 1:
                try{login();}
                catch(Exception e){}
                break;
            case 2:
                signup();
                break;
            case 3:
                System.out.println("Have a Nice Day!\n");
                System.exit(0);
            default:
                Validation.displayMessage("\t[-] Please try again.");
                break;
        }
    }

    public int login() throws InterruptedException {
        String username = Validation.getString("\t[+] Username: ");
        String passwd;
        Console console = System.console();
        if (console != null) {
            char[] passwordChars = console.readPassword("\t[+] Password: ");
            passwd = new String(passwordChars); 
        } else 
            passwd = Validation.getString("\t[+] Password: ");
        
        USERNAME = username;
        Validation.displayMessage("\tWaiting..");
    
        int res = userRepo.login(username, passwd);
    
        if (res < 0) {
            Validation.displayMessage("\n\t\033[1;31m[-]Login Failed! Incorrect username or password.\n\033[0m");
        } else if (res == 2) {
            Validation.displayMessage("\n\t\033[1;32mLogin Successful! Welcome Admin.\n\033[0m");
            Thread.sleep(2000);
            sys.clear();
            runAdminFunctions(); 
        } else if (res == 1) {
            Validation.displayMessage("\n\t\033[1;32mLogin Successful! Welcome "+USERNAME+" !\n\033[0m");
            Thread.sleep(2000);
            sys.clear();
            runUserFunctions();
        }
    
        return res;
    }
    
    private void runAdminFunctions() {
        AdminController admin = new AdminController();
        admin.run();
    }
    
    private void runUserFunctions() {
        UserController user = new UserController();
        user.run();
    }
    

    public int signup() {
        String fullname;
        do {
            fullname = Validation.getString("\t[+] Fullname: ");
            if (fullname == null || fullname.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Fullname cannot be empty.\n\033[0m");
            }
        } while (fullname == null || fullname.trim().isEmpty());
    
        String email;
        do {
            email = Validation.checkEmail(Validation.getString("\t[+] Email: "), "\n\t[-] Wrong format email");
            if (email == null || email.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Email cannot be empty or incorrect format.\n\033[0m");
            }
        } while (email == null || email.trim().isEmpty());
    
        String phone;
        do {
            phone = Validation.getString("\t[+] Phone: ");
            if (phone == null || phone.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Phone cannot be empty.\n\033[0m");
            }
        } while (phone == null || phone.trim().isEmpty());
    
        String address;
        do {
            address = Validation.getString("\t[+] Address: ");
            if (address == null || address.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Address cannot be empty.\n\033[0m");
            }
        } while (address == null || address.trim().isEmpty());
    
        String username;
        do {
            username = Validation.checkUserName(Validation.getString("\t[+] Username: "), "\n\t[-] Wrong username format\n");
            
            if (username == null || username.trim().isEmpty()) {
                Validation.displayMessage("\t\033[1;31m[-] Username cannot be empty or wrong format.\n\033[0m");
                continue;             
            }
    
            if (userRepo.isUserExists(username)) {
                Validation.displayMessage("\t\033[1;31m[-] Username already exists. Please try a different one.\033[0m");
                username = null;
            }
    
        } while (username == null || username.trim().isEmpty());
    
        Console console = System.console();
        String passwd = null;
        String passwd_conf = null;
        do {
            if (console != null) {
                char[] passwordChars = console.readPassword("\t[+] Password: ");
                passwd = new String(passwordChars); 

                if (Validation.checkPass(passwd, "\n\t[-] Password wrong format\n") == null) {
                    Validation.displayMessage("\t\033[1;31m[-] Password format is incorrect. Please enter again.\n\033[0m");
                    passwd = null;  
                    continue;
                }

                char[] confirmPasswordChars = console.readPassword("\t[+] Confirm Password: ");
                passwd_conf = new String(confirmPasswordChars);
            } else {
                passwd = Validation.checkPass(Validation.getString("\t[+] Password: "), "\n\t[-] Password wrong format\n");
                passwd_conf = Validation.getString("\t[+] Confirm Password: ");
            }

            if (!passwd.equals(passwd_conf)) {
                Validation.displayMessage("\t\033[1;31m[-] Passwords do not match. Please try again.\033[0m");
            }
        } while (passwd == null || passwd_conf == null || !passwd.equals(passwd_conf));
    
        Validation.displayMessage("----------------------------------------");
        USERNAME = username;
        int res = userRepo.signUp(username, passwd, email, "user", fullname, address, phone);
    
        if (res > 0) {
            Validation.displayMessage("\n\t\033[1;32m[+] Sign up successful.\n\t Please login to continue.\033[0m");
        } else {
            Validation.displayMessage("\n\t\033[1;31m[-] Sign up failed.\033[0m");
        }
    
        return res;
    }
    
    
    


   
}