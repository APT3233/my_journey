-- Bảng users: Lưu thông tin người dùng
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL, 
    email VARCHAR(100) NOT NULL,
    role ENUM('user', 'coach', 'admin') DEFAULT 'user',
    address VARCHAR(500),
    fullname VARCHAR(100),  
    phone VARCHAR(15),      
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng courses: Lưu thông tin về các khóa học
CREATE TABLE courses (
    courses_id INT AUTO_INCREMENT PRIMARY KEY,
    coach_name VARCHAR(100), 
    course_name VARCHAR(100) NOT NULL,
    description TEXT,         
    duration_weeks INT,      
    goal TEXT,              
    exercises TEXT,          
    nutrition_plan TEXT,      
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE coach (
    user_id INT PRIMARY KEY,                    
    subject_area VARCHAR(100),                  
    years_of_experience INT,                     
    biography TEXT                             

);