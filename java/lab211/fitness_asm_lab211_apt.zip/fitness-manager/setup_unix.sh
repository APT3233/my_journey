
# Initialize project with maven
mvn archetype:generate -DgroupId=com.example -DartifactId=fitness-app -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false


