package com.fitness.model.person;


public class Guest{
    private String phone;


    public Guest(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
